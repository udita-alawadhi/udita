package com.cg.ibs.im.dao;

import java.util.Set;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.AccountApplicant;
import com.cg.ibs.im.model.ApplicantStatus;

public interface AccountApplicantDao {

	Long saveAccountApplicant(AccountApplicant accountApplicant) throws IBSCustomException;

	Set<AccountApplicant> getAccountApplicantsByStatus(ApplicantStatus accountApplicantStatus)
			throws IBSCustomException;

	Set<AccountApplicant> getAllAccountApplicants() throws IBSCustomException;

	boolean updateAccountApplicant(AccountApplicant accountApplicant) throws IBSCustomException;

	boolean isAccountApplicantPresent(Long accountApplicantId) throws IBSCustomException;

	AccountApplicant getApplicantDetails(Long accountApplicantId) throws IBSCustomException;

}
