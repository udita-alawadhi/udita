package com.cg.ibs.im.dao;

import com.cg.ibs.im.model.AccountHolding;

public interface AccountHoldingDao {

	Long saveAccountHolding(AccountHolding accountHolding);

}
