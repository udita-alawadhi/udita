package com.cg.ibs.im;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.service.BankerService;
import com.cg.ibs.im.ui.Methods;

@SpringBootApplication
public class IbsV8Application implements CommandLineRunner {

	@Autowired
	private Methods methods;

	public static void main(String[] args) {
 
		SpringApplication.run(IbsV8Application.class, args);

	}

	@Override
	public void run(String... args) throws Exception {
 
		methods.signUp();
		
		
		try {
//			methods.createNewAccount(50001L);
			
//			methods.viewAccountApplicantWithId(50001L);
			
//			methods.sendAccountApplication("ckohli", AccountType.SAVINGS);
			
//			methods.sendAccountApplication("ualawadhi", AccountType.SAVINGS);
			
//			methods.viewAccountRequests();
			
//			methods.viewAccountApplicantWithId(50001L);
			
//			methods.viewAllAccounts();
			
//			methods.viewDeniedAccountRequests();
			
//			methods.customerLogin("ckohli", "t8KKKtjN");
			
//			methods.approveApplicantToCustomer(10106L);
			
//			methods.viewApplicantWithId(10105L);
			
//			methods.denyApplicant(10106L, "no documents");
			
//			methods.viewCustomerApprovals();
			
//			methods.viewCustomerDenials();
			
//			methods.viewCustomerRequests();
			
//			methods.bankerLogin("banker1", "pass1")
			
//			methods.checkStatus(10105L);
		} catch(Exception exception) {
			exception.printStackTrace();
		}
	}

}
