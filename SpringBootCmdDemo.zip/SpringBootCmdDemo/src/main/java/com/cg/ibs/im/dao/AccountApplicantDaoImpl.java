package com.cg.ibs.im.dao;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.model.AccountApplicant;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.ApplicantStatus;

@Repository("accountApplicantDao")
public class AccountApplicantDaoImpl implements AccountApplicantDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Long saveAccountApplicant(AccountApplicant accountApplication) throws IBSCustomException {
		Long accountApplicationId = new Long(0);
		if (accountApplication != null) {
			
			entityManager.persist(accountApplication);
			accountApplicationId = accountApplication.getAccountApplicantId();
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return accountApplicationId;
	}
	
	@Override
	public Set<AccountApplicant> getAllAccountApplicants() throws IBSCustomException {
		TypedQuery<AccountApplicant> query = entityManager.createNamedQuery("getAllAccountApplicants", AccountApplicant.class);
		List<AccountApplicant> applicantSet = query.getResultList();
		Set<AccountApplicant> applicants = new HashSet<AccountApplicant>();
		for (AccountApplicant applicantId : applicantSet) {
			applicants.add(applicantId);
		}
		return applicants;
	}
	
	
	@Override
	public Set<AccountApplicant> getAccountApplicantsByStatus(ApplicantStatus accountApplicantStatus) throws IBSCustomException {
		TypedQuery<AccountApplicant> query = entityManager.createNamedQuery("getAccountApplicantsByStatus", AccountApplicant.class);
		// set applicantSTatus
		query.setParameter("accountApplicantStatus", accountApplicantStatus);
		List<AccountApplicant> applicantSet = query.getResultList();
		Set<AccountApplicant> accountApplicants = new HashSet<AccountApplicant>();
		for (AccountApplicant applicantId : applicantSet) {
			accountApplicants.add(applicantId);
		}
		return accountApplicants;
	}
	
	@Override
	public boolean isAccountApplicantPresent(Long accountApplicantId) throws IBSCustomException {
		boolean result = false;
		AccountApplicant newAccountApplicant = entityManager.find(AccountApplicant.class, accountApplicantId);
		if (newAccountApplicant != null) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean updateAccountApplicant(AccountApplicant accountApplicant) throws IBSCustomException {
		boolean result = false;
		if (accountApplicant != null) {
			entityManager.merge(accountApplicant);
			result = true;
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return result;
	}
	
	@Override
	public AccountApplicant getApplicantDetails(Long accountApplicantId) throws IBSCustomException {
		AccountApplicant newAccountApplicant = new AccountApplicant();
		if (isAccountApplicantPresent(accountApplicantId)) {
			
			newAccountApplicant = entityManager.find(AccountApplicant.class, accountApplicantId);
			
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return newAccountApplicant;
	}
}

