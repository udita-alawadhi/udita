package com.cg.ibs.im.model;

import java.math.BigInteger;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@NamedQueries({
	@NamedQuery(name = "getAccountApplicantsByStatus", query = "select a from AccountApplicant a where " 
						+ "a.accountApplicationStatus= :accountApplicantStatus"),
	@NamedQuery(name = "getAllAccountApplicants", query = "select a from AccountApplicant a")
})
@Table(name = "account_applicants")
public class AccountApplicant {

	@Id
	@Column(name = "account_applicant_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ACC_APP_SQ")
	@SequenceGenerator(sequenceName = "ACCOUNT_APPLICANT_SEQUENCE", allocationSize = 1, name = "ACC_APP_SQ")
	private Long accountApplicantId;
	@Column(name = "account_type", nullable = false)
	private AccountType accountType;
	@Column(name = "account_application_status", nullable = false)
	private ApplicantStatus accountApplicationStatus;
	@Column(name = "account_application_date", nullable = false)
	private LocalDate accountApplicationDate;
	@Column(name = "primary_customer", nullable = false)
	private BigInteger primaryCustomer;
	@Column(name = "secondary_customer")
	private BigInteger secondaryCustomer;
	@Column(name = "assigned_banker")
	private Integer assignedBanker;

	@Override
	public String toString() {
		return "AccountApplicant [accountApplicantId=" + accountApplicantId + ", accountType=" + accountType
				+ ", accountApplicationStatus=" + accountApplicationStatus + ", accountApplicationDate="
				+ accountApplicationDate + ", primaryCustomer=" + primaryCustomer + ", secondaryCustomer="
				+ secondaryCustomer + ", assignedBanker=" + assignedBanker + "]";
	}

	public Integer getAssignedBanker() {
		return assignedBanker;
	}

	public void setAssignedBanker(Integer assignedBanker) {
		this.assignedBanker = assignedBanker;
	}

	public Long getAccountApplicantId() {
		return accountApplicantId;
	}

	public void setAccountApplicantId(Long accountApplicantId) {
		this.accountApplicantId = accountApplicantId;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public ApplicantStatus getAccountApplicationStatus() {
		return accountApplicationStatus;
	}

	public void setAccountApplicationStatus(ApplicantStatus accountApplicationStatus) {
		this.accountApplicationStatus = accountApplicationStatus;
	}

	public LocalDate getAccountApplicationDate() {
		return accountApplicationDate;
	}

	public void setAccountApplicationDate(LocalDate accountApplicationDate) {
		this.accountApplicationDate = accountApplicationDate;
	}

	public BigInteger getPrimaryCustomer() {
		return primaryCustomer;
	}

	public void setPrimaryCustomer(BigInteger primaryCustomer) {
		this.primaryCustomer = primaryCustomer;
	}

	public BigInteger getSecondaryCustomer() {
		return secondaryCustomer;
	}

	public void setSecondaryCustomer(BigInteger secondaryCustomer) {
		this.secondaryCustomer = secondaryCustomer;
	}
}
