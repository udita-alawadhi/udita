package com.cg.ibs.im.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.ibs.im.model.AccountHolding;

@Repository("accountHoldingDao")
public class AccountHoldingDaoImpl implements AccountHoldingDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Long saveAccountHolding(AccountHolding accountHolding) {
		Long a = new Long(0);
		
		if(accountHolding!=null) {
			entityManager.persist(accountHolding);
			a = accountHolding.getaHId();
			System.out.println(a);
		}
		return a;
	}
}
