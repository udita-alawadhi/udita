package com.cg.ibs.im.service;

import java.math.BigInteger;
import java.util.Set;

import com.cg.ibs.im.model.AccountApplicant;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.Customer;
import com.cg.ibs.im.exception.IBSCustomException;

public interface BankerService {
	
	boolean verifyBankerLogin(String user, String password) throws IBSCustomException;
	
	Set<Applicant> viewPendingApplications() throws IBSCustomException;
	
	Set<Applicant> viewApprovedApplications() throws IBSCustomException;
	
	Set<Applicant> viewDeniedApplications() throws IBSCustomException;
	
	boolean updateCustomer(Customer customer) throws IBSCustomException;
	
	String generatePassword(long applicantId);
	
	Customer createNewCustomer(Applicant applicant) throws IBSCustomException;

	boolean isApplicantPresentInPendingList(long applicantId) throws IBSCustomException;

	boolean isApplicantPresent(long applicantId) throws IBSCustomException;

	String generateUsername(long applicantId) throws IBSCustomException;

	boolean download(Applicant applicant) throws IBSCustomException;

	Set<AccountApplicant> viewPendingAccountApplications() throws IBSCustomException;

	Set<AccountApplicant> viewDeniedAccountApplications() throws IBSCustomException;

	Set<AccountApplicant> viewApprovedAccountApplications() throws IBSCustomException;

	Applicant displayDetails(Long applicantId) throws IBSCustomException;

	AccountApplicant displayApplication(Long accountApplication) throws IBSCustomException;

	BigInteger createNewAccount(AccountApplicant accountApplicant) throws IBSCustomException;
}
