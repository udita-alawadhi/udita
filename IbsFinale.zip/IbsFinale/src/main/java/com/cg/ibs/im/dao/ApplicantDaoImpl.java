package com.cg.ibs.im.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.ApplicationStatus;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;

@Repository("applicantDao")
public class ApplicantDaoImpl implements ApplicantDao {
	
	@PersistenceContext
	private EntityManager entityManager;


	@Override
	public Long saveApplicant(Applicant applicant) throws IBSCustomException {
		Long applicationId = new Long(0);
		if (applicant != null) {
			entityManager.persist(applicant);
			applicationId = applicant.getApplicantId();
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return applicationId;
	}

	@Override
	public Set<Long> getAllApplicants() throws IBSCustomException {
		TypedQuery<Long> query = entityManager.createNamedQuery("getAllApplicants", Long.class);
		List<Long> applicantSet = query.getResultList();
		Set<Long> applicants = new HashSet<Long>();
		for (Long applicantId : applicantSet) {
			applicants.add(applicantId);
		}
		return applicants;
	}

	@Override
	public Applicant getApplicantDetails(Long applicantId) throws IBSCustomException {
		Applicant newApplicant = new Applicant();
		if (isApplicantPresent(applicantId)) {
			
			newApplicant = entityManager.find(Applicant.class, applicantId);
			
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return newApplicant;
	}

	@Override
	public Set<Applicant> getApplicantsByStatus(ApplicationStatus applicantStatus) throws IBSCustomException {
		TypedQuery<Applicant> query = entityManager.createNamedQuery("getApplicantsByStatus", Applicant.class);
		// set applicantSTatus
		query.setParameter("applicantStatus", applicantStatus);
		List<Applicant> applicantSet = query.getResultList();
		Set<Applicant> applicants = new HashSet<Applicant>();
		for (Applicant applicantId : applicantSet) {
			applicants.add(applicantId);
		}
		return applicants;
	}

	@Override
	public boolean isApplicantPresent(long applicantId) throws IBSCustomException {
		boolean result = false;
		Applicant newApplicant = entityManager.find(Applicant.class, applicantId);
		if (newApplicant != null) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean updateApplicant(Applicant applicant) throws IBSCustomException {
		boolean result = false;
		if (applicant != null) {
			entityManager.merge(applicant);
			result = true;
		} else {
			throw new IBSCustomException(IBSException.SQLError);
		}
		return result;
	}

}
