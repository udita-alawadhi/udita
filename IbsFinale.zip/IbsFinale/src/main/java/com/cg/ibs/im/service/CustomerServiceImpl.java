package com.cg.ibs.im.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.Period;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.im.dao.AddressDao;
import com.cg.ibs.im.dao.ApplicantDao;
import com.cg.ibs.im.dao.ApplicationDao;
import com.cg.ibs.im.dao.CustomerDao;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;
import com.cg.ibs.im.model.Address;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.ApplicationStatus;
import com.cg.ibs.im.model.Customer;

@Transactional
@Service("customerService")
public class CustomerServiceImpl implements CustomerService {
	private static Logger LOGGER = Logger.getLogger(BankerServiceImpl.class);

	@Autowired
	private ApplicantDao applicantDao;
	@Autowired
	private AddressDao addressDao;
	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private ApplicationDao applicationDao;

	public CustomerServiceImpl() {
		super();
	}
	
	

//	// TODO
	@Override
	public boolean verifyApplicantId(long applicantId) throws IBSCustomException {
		LOGGER.info("In verifyApplicantId method");

		boolean result = false;
		if (applicantDao.isApplicantPresent(applicantId)) {
			LOGGER.debug("applicantId is present in Dao");

			if (applicantDao.getApplicantDetails(applicantId).getApplicantId() == applicantId) {
				result = true;
			}
		}
		return result;
	}

	@Override
	public boolean verifyAppId(String appId) {
		LOGGER.info("In verifyAppId method");

		return appId.matches("[0-9]{5}");
	}

	@Override
	public boolean login(String userId, String password) throws IBSCustomException {
		LOGGER.info("login using userId and password");
		Customer customer;
		boolean result = false;
		try {
			customer = getCustomerDetails(userId);
		} catch (IBSCustomException exception) {
			customer = null;
		}
		if (customer != null) {
			LOGGER.debug("Customer is present");

			if (customer.getUserId().toString().equals(userId)) {
				LOGGER.debug("Customer userId matches");

				if (customer.getPassword().equals(password)) {
					LOGGER.debug("Customer password matches");

					result = true;
				} else {
					result = false;
				}
			} else {
				LOGGER.error("Incorrect userId");

				throw new IBSCustomException(IBSException.incorrectUsernamePassword);
			}
		} else {
			throw new IBSCustomException(IBSException.incorrectUsernamePassword);
		}
		return result;
	}

	@Override
	public boolean verifyName(String name) {
		LOGGER.info("VerifyName method");
		return name.matches("[a-zA-z ]+");
	}

	@Override
	public boolean verifyDob(LocalDate ld) {
		LOGGER.info("In verifyDob method");

		boolean result = false;
		LocalDate date = LocalDate.now();
		Period age = Period.between(ld, date);
		int agen = age.getYears();

		if (agen >= 18 && agen < 110) {
			LOGGER.debug("Customer age is between 18 and 110");

			result = true;
		}
		return result;
	}

	@Override
	public Customer getCustomerByUserId(String userId) throws IBSCustomException{
		Customer customer;
		if(customerDao.checkCustomerByUsernameExists(userId)) {
			customer = customerDao.getCustomerDetails(userId);
		} else {
			throw new IBSCustomException(IBSException.customerNotPresent);
		}
		return customer;
	}
	
	@Override
	public boolean verifyMobileNumber(String mobileNumber) {
		LOGGER.info("In VerifyMobileNumber method");

		Pattern pattern = Pattern.compile("[6-9][0-9]{9}");
		Matcher matcher = pattern.matcher(mobileNumber);
		return (matcher.find() && matcher.group().equals(mobileNumber));
	}

	@Override
	public boolean verifyAadharNumber(String aadharNumber) {
		LOGGER.info("In verifyAadharNumber method");

		return aadharNumber.matches("[0-9]{12}") || aadharNumber.matches("[0-9]{4} [0-9]{4} [0-9]{4}");
	}

	@Override
	public boolean verifyPincode(String pinCode) {
		LOGGER.info("In verifyPincode method");

		return pinCode.matches("[0-9]{6}");
	}

	@Override
	public boolean verifyPanNumber(String panNumber) {
		LOGGER.info("In verifyPanNumber method");

		Pattern pattern = Pattern.compile("[A-Z]{5}[0-9]{4}[A-Z]{1}");
		Matcher matcher = pattern.matcher(panNumber);
		return (matcher.find() && matcher.group().equals(panNumber));
	}

	@Override
	public boolean verifyEmailId(String emailId) {
		LOGGER.info("In verifyEmailId method");

		return matchesAtLeastOneRegex(emailId);
	}

	public boolean matchesAtLeastOneRegex(String input) {
		LOGGER.info("In matchesAtLeastOneRegex method");

		Pattern pattern1 = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9+]+.[a-z]+$");
		Pattern pattern2 = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9+]+.[a-z]+.[a-z]+$");

		Matcher matcher1 = pattern1.matcher("");
		Matcher matcher2 = pattern2.matcher("");
		return matcher1.reset(input).matches() || matcher2.reset(input).matches();
	}

	@Override
	public boolean verifyMobileNumbers(String mobile1, String mobile2) {
		LOGGER.info("In verifyMobileNumbers method");

		boolean result = false;
		if (mobile1.equals(mobile2)) {
			LOGGER.debug("Customer's Mobile number and Alternate Mobile number is same");

			result = true;
		}
		return result;
	}

	@Override
	public boolean checkCustomerDetails(String confirm1, String confirm2) {
		LOGGER.info("In checkCustomerDetails method");

		boolean result = false;
		if (confirm1.equals(confirm2)) {
			result = true;
		}
		return result;
	}

	@Override
	public Long saveApplicationDetails(Application application) throws IBSCustomException {
		application.setApplicationStatus(ApplicationStatus.PENDING);
		application.setApplicationDate(LocalDate.now());
		application.setRemarks("None");
		Long app = saveApplicantDetails(application.getPrimaryApplicant());
		if(application.getSecondaryApplicant()!=null) {
			Long sec = saveApplicantDetails(application.getSecondaryApplicant());
		}
		Long result = applicationDao.saveApplication(application);
		application.setAssignedBanker(assignBanker(result));
		applicationDao.updateApplication(application);
		return result;

	}
	
	@Override
	public Long saveApplicantDetails(Applicant applicant) throws IBSCustomException {

		saveAddress(applicant.getAddress());
		Long result = applicantDao.saveApplicant(applicant);
		return result;
	}

	public int assignBanker(Long applicantId) {
		int banker;
		int num = Integer.parseInt(applicantId.toString())%5;

		banker = num+1;
		return banker;
	}

	@Override
	public Customer getCustomerDetails(String userId) throws IBSCustomException {
		LOGGER.info("In getCustomerDetails method");

		return customerDao.getCustomerDetails(userId);
	}

	@Override
	public boolean firstLogin(String userId) throws IBSCustomException {
		LOGGER.info("In firstLogin method");

		boolean result = false;
		Customer customer = getCustomerDetails(userId);
		if (customer.getLogin() == 0) {

		LOGGER.debug("Customer's first login");

			result = true;
		}
		return result;
	}

	@Override
	public Applicant getApplicantDetails(Long applicantId) throws IBSCustomException {
		LOGGER.info("In getApplicantDetails method");

		return applicantDao.getApplicantDetails(applicantId);
	}

	@Override
	public Customer getCustomerByApplicantId(Long applicantId) throws IBSCustomException {
		LOGGER.info("In getCustomerByApplicantId method");

		return customerDao.getCustomerByApplicantId(applicantId);
	}

	@Override
	public boolean isCustomerValid(String userId) throws IBSCustomException {
		LOGGER.info("In isCustomerValid method");

		boolean result = false;
		Customer customer = customerDao.getCustomerDetails(userId);
		if (customer != null) {
			LOGGER.debug("Customer is valid");

			result = true;
		}
		return result;
	}

	@Override
	public Long saveAddress(Address address) throws IBSCustomException {
		LOGGER.info("In saveAddress(AddressBean) method");
		// no need to start transaction again
		Long addressId = addressDao.saveAddress(address);
		return addressId;
	}

	
	@Override
	public boolean updateApplication(Application application) throws IBSCustomException {

		boolean result = false;

		result = applicationDao.updateApplication(application);
		LOGGER.info("Applicant's status updated");

		return result;
	}

	@Override
	public ApplicationStatus checkStatus(Long applicationId) throws IBSCustomException {
		LOGGER.info("In checkStatus method");
		
		Application application = applicationDao.getApplicationDetails(applicationId);
		return application.getApplicationStatus();
	}

	
	@Override
	public boolean updateCustomer(Customer customer) throws IBSCustomException {
		LOGGER.info("In updateCustomer(CustomerBean) method");

		boolean result = false;

		String pass = customer.getPassword();
		Customer cust = customerDao.getCustomerDetails(customer.getUserId());
		cust.setPassword(pass);
		cust.setLogin(new Integer(1));
		LOGGER.info("Customer's status updated");
		result = true;
		return result;
	}

	@Override
	public void uploadDocuments(Applicant applicant, String aadharPath, String panPath)
			throws IBSCustomException, FileNotFoundException {
		LOGGER.info("In uploadDocuments(ApplicantBean) method");

		applicant.setAadharDocument(uploadDocument(aadharPath));
		applicant.setPanDocument(uploadDocument(panPath));
	}

	private static byte[] uploadDocument(String path) throws IBSCustomException, FileNotFoundException {
		LOGGER.info("In uploadDocument method");

		byte[] content = null;
		try (FileInputStream inputStream = new FileInputStream(path)) {
			content = new byte[(int) inputStream.available()];
			inputStream.read(content);
		} catch (IOException exception) {
			LOGGER.error("uploadDocument is showing exception");

			throw new IBSCustomException(IBSException.ioexception);
		}
		return content;
	}

	@Override
	public boolean saveCustomerDetails(Customer customer) throws IBSCustomException {
		LOGGER.info("In saveCustomerDetails(Customer Bean) method");

		boolean result = false;

		customerDao.saveCustomer(customer);
		LOGGER.info("Customer's details saved");
		result = true;
		return result;
	}

	@Override
	public boolean checkCustomerByUserIdExists(String userId) throws IBSCustomException {
		boolean result = false;
		result = customerDao.checkCustomerByUsernameExists(userId);
		return result;
	}

}
