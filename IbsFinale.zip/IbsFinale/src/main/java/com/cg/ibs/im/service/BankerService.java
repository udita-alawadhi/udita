package com.cg.ibs.im.service;

import java.util.Set;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.Customer;

public interface BankerService {
	
	boolean verifyBankerLogin(String user, String password) throws IBSCustomException;
	
	Set<Application> viewPendingApplications() throws IBSCustomException;
	
	Set<Application> viewApprovedApplications() throws IBSCustomException;
	
	Set<Application> viewDeniedApplications() throws IBSCustomException;
	
	boolean updateCustomer(Customer customer) throws IBSCustomException;
	
	String generatePassword(Long applicantId);
	
	Customer createNewCustomer(Application application) throws IBSCustomException;

	boolean isApplicantPresentInPendingList(Long applicantId) throws IBSCustomException;

	boolean isApplicantPresent(Long applicantId) throws IBSCustomException;

	String generateUsername(Long applicantId) throws IBSCustomException;

	boolean download(Applicant applicant) throws IBSCustomException;

	Application displayDetails(Long applicationId) throws IBSCustomException;

	Set<Application> viewPendingApplicationsBanker(Integer bankerId) throws IBSCustomException;
}
