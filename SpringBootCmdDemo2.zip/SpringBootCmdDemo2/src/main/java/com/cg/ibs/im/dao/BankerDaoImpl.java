package com.cg.ibs.im.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.Banker;

@Repository("bankerDao")
public class BankerDaoImpl implements BankerDao{
	private Banker bankAdmin;
	@PersistenceContext
	private EntityManager entityManager;
	private static Logger LOGGER = Logger.getLogger(AccountDaoImpl.class);

	
////	public BankerDaoImpl() {
////		super();
//////		addNewBanker();
////	}
//	
////	@Transactional
////	@Override
////	public BankAdmins addNewBanker() {
////		BankAdmins bankAdmin = new BankAdmins("id1", "pass1");
////		entityManager.merge(bankAdmin);
////		return bankAdmin;
////	}
//	
	@Override
	public boolean checkBankerLogin(String adminId, String password) throws IBSCustomException {
		LOGGER.info("Into checkBankerLogin method");
		boolean result = false;
		//CHANGE
		String sid = adminId.substring(6, 7);
		System.out.println(sid);
		Integer id = Integer.parseInt(sid);
		System.out.println(id);
		bankAdmin = entityManager.find(Banker.class, id);
		System.out.println(bankAdmin.getBankerId()+" "+bankAdmin.getPassword());
		if(bankAdmin!=null) {
			LOGGER.info("bank admin exists.");
			if(bankAdmin.getPassword().equals(password)) {
				LOGGER.debug("Correct password");
				result = true;
			}
		}
		return result;
	}
}
