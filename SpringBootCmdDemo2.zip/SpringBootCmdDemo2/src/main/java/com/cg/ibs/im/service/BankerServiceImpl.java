package com.cg.ibs.im.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.im.dao.AccountDao;
import com.cg.ibs.im.dao.ApplicantDao;
import com.cg.ibs.im.dao.ApplicationDao;
import com.cg.ibs.im.dao.BankerDao;
import com.cg.ibs.im.dao.CustomerDao;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.Account;
import com.cg.ibs.im.model.AccountHolding;
import com.cg.ibs.im.model.AccountHoldingType;
import com.cg.ibs.im.model.AccountStatus;
import com.cg.ibs.im.model.AccountType;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.ApplicationStatus;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.Customer;

@Service("bankerService")
public class BankerServiceImpl implements BankerService {

	@Autowired
	private BankerDao bankerDao;
	@Autowired
	private ApplicantDao applicantDao;
	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private AccountDao accountDao;
	@Autowired
	private ApplicationDao applicationDao;
	
	private static Logger LOGGER = Logger.getLogger(BankerServiceImpl.class);
	


	@Override
	public boolean verifyBankerLogin(String user, String password) throws IBSCustomException {
		LOGGER.info("In verifyBankerLogin method");
		boolean result = false;
		result = bankerDao.checkBankerLogin(user, password);
		return result;
	}

	
	//change to view all pending requests
	@Override
	public Set<Application> viewPendingApplications() throws IBSCustomException {
		LOGGER.info("In viewPendingApplications method");

		return applicationDao.getApplicationByStatus(ApplicationStatus.PENDING);
	}
	
//	public Set<Applicant> viewPendingApplicationsToBeChecked(Integer bankerId) throws IBSCustomException {
//		LOGGER.info("In viewPendingApplications method");
//
//		Set<Applicant> set = applicantDao.getApplicantsByStatus(ApplicationStatus.PENDING);
//		
//		
//		
//		Set<Applicant> newSet = new HashSet<Applicant>();
//		
//		for(Applicant a: set) {
//			if(a.getAssignedBanker() == bankerId) {
//				newSet.add(a);
//			}
//		}
//		
//		return newSet;
//	}

	@Override
	public Set<Application> viewApprovedApplications() throws IBSCustomException {
		LOGGER.info("In viewApprovedApplications method");

		return applicationDao.getApplicationByStatus(ApplicationStatus.APPROVED);
	}
	
	@Override
	public Set<Application> viewDeniedApplications() throws IBSCustomException {
		LOGGER.info("In viewDeniedApplications method");

		return applicationDao.getApplicationByStatus(ApplicationStatus.DENIED);
	}
	
	@Override
	public String generatePassword(Long applicantId) {
		LOGGER.info("In generatePassword method");

		String alphaNumeric = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
		StringBuilder stringBuffer = new StringBuilder(8);

		for (int i = 0; i < 8; i++) {
			int index = (int) (alphaNumeric.length() * Math.random());
			stringBuffer.append(alphaNumeric.charAt(index));
		}
		return stringBuffer.toString();
	}

	@Override
	public boolean isApplicantPresentInPendingList(Long applicantId) throws IBSCustomException {
		LOGGER.info("In isApplicantPresentInPendingList method");

		boolean result = false;
		if (applicantId != 0) {
			LOGGER.debug("applicantId is not zero");

			Set<Applicant> pendingApplicants = applicantDao.getApplicantsByStatus(ApplicationStatus.PENDING);
			Iterator<Applicant> it = pendingApplicants.iterator();
			while (it.hasNext()) {
				if (it.next().getApplicantId() == applicantId) {
					result = true;
					break;
				}
			}
		}
		return result;
	}

	@Override
	public boolean isApplicantPresent(Long applicantId) throws IBSCustomException {
		return applicantDao.isApplicantPresent(applicantId);
	}

	@Override
	public Application displayDetails(Long applicationId) throws IBSCustomException {
		
		Application application = applicationDao.getApplicationDetails(applicationId);
		
		return application;
	}

	@Override
	public String generateUsername(Long applicationId) throws IBSCustomException {
		Application application = applicationDao.getApplicationDetails(applicationId);

		String username = application.getPrimaryApplicant().getFirstName().charAt(0) + application.getPrimaryApplicant().getLastName();
		if (username.length() > 12) {
			username = username.substring(0, 10);
		}
		int index = 1;
		while (!checkUsernameIsUnique(username)) {
			username = username.concat(String.valueOf(index));
			if (username.length() > 15) {
				username = username.substring(0, 14);
			}
			index++;
		}
		return username;
	}

	public boolean checkUsernameIsUnique(String username) {
		boolean result = true;
		try {
			if (customerDao.checkCustomerByUsernameExists(username)) {
				result = false;
			}
		} catch (Exception exception) {
			exception.getMessage();
		}
		return result;
	}

	@Override
	public boolean download(Applicant applicant) throws IBSCustomException {
		boolean result = false;
		byte[] aadhar = applicant.getAadharDocument();
		byte[] pan = applicant.getPanDocument();
		File dir = new File("./downloads");
		if (!dir.exists()) {
			dir.mkdir();
		}
		try (FileOutputStream outputStream1 = new FileOutputStream(
				dir.getPath() + "/" + applicant.getApplicantId() + "aadhar.pdf");
				FileOutputStream outputStream2 = new FileOutputStream(
						dir.getPath() + "/" + applicant.getApplicantId() + "pan.pdf")) {
			outputStream1.write(aadhar);
			outputStream1.flush();
			outputStream1.close();
			outputStream2.write(pan);
			outputStream2.flush();
			outputStream2.close();
			result = true;
		} catch (FileNotFoundException e) {
			e.getMessage();
		} catch (IOException e) {
			e.getMessage();
		}
		return result;

	}

//	@Transactional
//	@Override
//	public Customer createNewCustomer(Applicant applicant) throws IBSCustomException {
//		Customer customer = new Customer();
//		try {
//			customer = saveNewCustomer(applicant);
//			
//			AccountHolding ah = new AccountHolding();
//			//INDIVIDUAL ACCOUNT
//			if (applicant.getLinkedApplication().equals(new Long(0))) {
//				Account account = new Account();
//				AccountHoldingType aHType = AccountHoldingType.INDIVIDUAL;
//				account = new Account();
//				account.setBalance(new BigDecimal(0));
//				account.setTrans_Pwd("password");
//				account.setAccCreationDate(LocalDate.now());
//				account.setOpenBalance(new BigDecimal(0));
//				account.setAccStatus(AccountStatus.ACTIVE);
//
//				account.setAccType(AccountType.SAVINGS);
//				ah.setCustomer(customer);
//				ah.setAccount(account);
//				ah.setType(aHType);
//				Set<AccountHolding> ahSet = Collections.singleton(ah);
//				account.setAccountHoldings(ahSet);
//				customer.setAccountHoldings(ahSet);
//
//				accountDao.saveAccount(account);
//
//			} else if (applicant.getLinkedApplication().equals(new Long(555))) {
//				// set account holdings accordingly
//				//JOINT ACCOUNT SECONDARY 
//			} else {
//				//JOINT ACCOUNT PRIMARY
//				
//				Account account = new Account();
//				account.setBalance(new BigDecimal(0));
//				account.setTrans_Pwd("password");
//				account.setAccCreationDate(LocalDate.now());
//				account.setOpenBalance(new BigDecimal(0));
//				account.setAccStatus(AccountStatus.ACTIVE);
//				account.setAccType(AccountType.JOINT_SAVINGS);
//								
//				Long appId = customer.getApplicantId();
//				Long linkedAppId = applicantDao.getApplicantDetails(appId).getLinkedApplication();
//				Applicant applicant1 = applicantDao.getApplicantDetails(linkedAppId);
//				applicant1.setApplicantStatus(ApplicantStatus.APPROVED);				
//				applicantDao.updateApplicant(applicant1);
//				
//				Customer customer1 = saveNewCustomer(applicant1);
//				
//				ah = new AccountHolding();
//				ah.setCustomer(customer);
//				ah.setAccount(account);
//				ah.setType(AccountHoldingType.PRIMARY);
//
//				AccountHolding ah2 = new AccountHolding();
//				ah2.setAccount(account);
//				ah2.setCustomer(customer1);
//				ah2.setType(AccountHoldingType.SECONDARY);
//
//				Set<AccountHolding> ahSet = new HashSet<AccountHolding>();
//				ahSet.add(ah);
//				ahSet.add(ah2);
//				account.setAccountHoldings(ahSet);
//				
//				customer.setAccountHoldings(Collections.singleton(ah));
//				customer1.setAccountHoldings(Collections.singleton(ah2));
//				
//				accountDao.saveAccount(account);				
//			}
//
//			// create the account for that customer
//			// from application
//		} catch (Exception exception) {
//			exception.getMessage();
//		}
//
//		return customer;
//	}
	
	public Customer saveNewCustomer(Applicant applicant) throws IBSCustomException {

		Customer customer = new Customer();
		Long applicantId = applicant.getApplicantId();
		String userId = generateUsername(applicantId);
		customer.setUserId(userId);
		customer.setPassword(generatePassword(applicantId));
		customer.setApplicationId(applicantId);
		customer.setFirstName(applicant.getFirstName());
		customer.setLastname(applicant.getLastName());
		customer.setFatherName(applicant.getFatherName());
		customer.setMotherName(applicant.getMotherName());
		customer.setDateofBirth(applicant.getDob());
		customer.setGender(applicant.getGender());
		customer.setMobileNumber(applicant.getMobileNumber());
		customer.setAlternateMobileNumber(applicant.getAlternateMobileNumber());
		customer.setEmailId(applicant.getEmailId());
		customer.setAadharNumber(applicant.getAadharNumber());
		customer.setPanNumber(applicant.getPanNumber());
		customer.setLogin(new Integer(0));
		customer.setAddress(applicant.getAddress());
		customerDao.saveCustomer(customer);
		return customer;
	}

	@Transactional
	@Override
	public boolean updateCustomer(Customer customer) throws IBSCustomException {
		boolean result = false;
		result = customerDao.updateCustomer(customer);
		return result;
	}

	@Transactional
	@Override
	public Customer createNewCustomer(Application application) throws IBSCustomException {
		Customer customer = new Customer();
		
		Long applicationId = application.getApplicationId();
		String userId = generateUsername(applicationId);
		
		customer.setUserId(userId);
		customer.setPassword(generatePassword(applicationId));
		
		customer.setApplicationId(applicationId);
		Applicant applicant = application.getPrimaryApplicant();
		customer.setFirstName(applicant.getFirstName());
		customer.setLastname(applicant.getLastName());
		customer.setFatherName(applicant.getFatherName());
		customer.setMotherName(applicant.getMotherName());
		customer.setDateofBirth(applicant.getDob());
		customer.setGender(applicant.getGender());
		customer.setMobileNumber(applicant.getMobileNumber());
		customer.setAlternateMobileNumber(applicant.getAlternateMobileNumber());
		customer.setEmailId(applicant.getEmailId());
		customer.setAadharNumber(applicant.getAadharNumber());
		customer.setPanNumber(applicant.getPanNumber());
		customer.setLogin(new Integer(0));
		customer.setAddress(applicant.getAddress());
		Set<AccountHolding> ah = new HashSet<AccountHolding>();
		customer.setAccountHoldings(ah);
		AccountHolding accountHolding = new AccountHolding();
		System.out.println(customer.getEmailId());

		Customer result=customerDao.saveCustomer(customer);
		Account account = createNewAccount(application);
		
		accountHolding.setAccount(account);
		accountHolding.setCustomer(result);
		accountHolding.setType(AccountHoldingType.INDIVIDUAL);
		
		ah.add(accountHolding); //change
		
		customer.getAccountHoldings().add(accountHolding);
		account.getAccountHoldings().add(accountHolding);
		
		return result;
	}
	
	public Account createNewAccount(Application application) throws IBSCustomException {
		Account account = new Account();
		BigInteger accNo = new BigInteger("0");
		
		account.setAccCreationDate(LocalDate.now());
		account.setAccStatus(AccountStatus.ACTIVE);
		account.setAccType(application.getAccountType());
		account.setBalance(new BigDecimal(0));
		account.setOpenBalance(new BigDecimal(0));
		account.setTrans_Pwd("1111");
		
		Set<AccountHolding> ah = new HashSet<AccountHolding>();
		account.setAccountHoldings(ah);
		accNo = accountDao.saveAccount(account);
		System.out.println(accNo);
		return account;
	}
	
//	@Transactional
//	@Override
//	public BigInteger createNewAccount(AccountApplicant accountApplicant) throws IBSCustomException {
//		Account account = new Account();
//		BigInteger accNo = new BigInteger("0");
//		
//		account.setAccCreationDate(LocalDate.now());
//		account.setAccStatus(AccountStatus.ACTIVE);
//		account.setAccType(accountApplicant.getAccountType());
//		account.setBalance(new BigDecimal(0));
//		account.setOpenBalance(new BigDecimal(0));
//		account.setTrans_Pwd("1111");
//		
//		Set<AccountHolding> acholdings = new HashSet<AccountHolding>();
//		account.setAccountHoldings(acholdings);
//		accNo = accountDao.saveAccount(account);
//		System.out.println(accNo);
//		AccountHolding ah = new AccountHolding();
//		
//		
//		Customer customer = customerDao.getCustomerByUci(accountApplicant.getPrimaryCustomer());
//		if(accountApplicant.getAccountType()==AccountType.SAVINGS) {
//			ah.setAccount(account);
//			ah.setType(AccountHoldingType.INDIVIDUAL);
//			ah.setCustomer(customer);
//			
////			Long a = accountHoldingDao.saveAccountHolding(ah);
////			customer.getAccountHoldings().add(ah);
//			
////			System.out.println(a);
//			account.getAccountHoldings().add(ah);
//			
//		} else {
//			
//		}
//		
////		BigInteger accNo = accountDao.saveAccount(account);
//		
////		if(accountApplicant.getAccountType()==AccountType.SAVINGS) {
////			updateAccountHoldingsCustomer(customer, ah);
////		} else {
////			
////		}
////		
//		accountApplicant.setAccountApplicationStatus(ApplicationStatus.APPROVED);
//		accountApplicantDao.updateAccountApplicant(accountApplicant);
//		return accNo;
//	}
	
	public boolean updateAccountHoldingsCustomer(Customer customer, AccountHolding accountHolding) throws IBSCustomException {
		boolean result = false;
		
		BigInteger uci = customer.getUci();
		Customer cust = customerDao.getCustomerByUci(uci);
		Set<AccountHolding> customerHoldings = cust.getAccountHoldings();
		customerHoldings.add(accountHolding);
		cust.setAccountHoldings(customerHoldings);
		return result;
	}
	
//	@Transactional
//	@Override
//	public boolean addAccountToCustomer(AccountApplicant accountApplicant) throws IBSCustomException {
//		boolean result = false;
//		 
//		Customer customer = customerDao.getCustomerByUci(uci);
//		Account account = accountDao.getAccount(accountNumber);
//		
//		Set<AccountHolding> accountHoldings = new HashSet<AccountHolding>();
//		AccountHolding ah = new AccountHolding();
//		
//		
//		return result;
//	}

}
