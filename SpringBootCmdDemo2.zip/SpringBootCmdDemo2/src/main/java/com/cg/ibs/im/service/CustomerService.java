package com.cg.ibs.im.service;

import java.io.FileNotFoundException;
import java.time.LocalDate;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.Address;
import com.cg.ibs.im.model.Applicant;
import com.cg.ibs.im.model.Application;
import com.cg.ibs.im.model.ApplicationStatus;
import com.cg.ibs.im.model.Customer;

public interface CustomerService {
	boolean verifyApplicantId(long applicantId) throws IBSCustomException;
	
	boolean checkCustomerByUserIdExists(String userId) throws IBSCustomException;
	
	ApplicationStatus checkStatus(Long applicantId) throws IBSCustomException;
	
	boolean login(String username, String password) throws IBSCustomException;
	
	boolean verifyName(String name);

	boolean verifyDob(LocalDate ld);

	boolean verifyMobileNumber(String mobileNumber);

	boolean verifyAadharNumber(String aadharNumber);

	boolean verifyPincode(String pinCode);

	boolean verifyPanNumber(String panNumber);

	boolean verifyEmailId(String emailId);

	boolean verifyMobileNumbers(String mobile1, String mobile2);

	boolean checkCustomerDetails(String confirm1, String confirm2);

	Long saveApplicantDetails(Applicant applicant) throws IBSCustomException;

	boolean saveCustomerDetails(Customer customerBean) throws IBSCustomException;

	Customer getCustomerDetails(String uci) throws IBSCustomException;

	boolean firstLogin(String userId) throws IBSCustomException;

	Applicant getApplicantDetails(Long applicantId) throws IBSCustomException;

	Customer getCustomerByApplicantId(Long applicantId) throws IBSCustomException;

	boolean isCustomerValid(String uci) throws IBSCustomException;

	Long saveAddress(Address address) throws IBSCustomException;
	
	boolean updateApplication(Application application) throws IBSCustomException;

	boolean updateCustomer(Customer customer) throws IBSCustomException;

	void uploadDocuments(Applicant applicant, String aadharPath, String panPath) throws IBSCustomException, FileNotFoundException;

	boolean verifyAppId(String appId);

	Customer getCustomerByUserId(String userId) throws IBSCustomException;

	Long saveApplicationDetails(Application application) throws IBSCustomException;

}
