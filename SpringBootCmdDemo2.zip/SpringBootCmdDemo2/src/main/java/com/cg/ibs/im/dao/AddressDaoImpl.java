package com.cg.ibs.im.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.ibs.im.model.Address;
import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.exception.IBSException;


@Repository("addressDao")
public class AddressDaoImpl implements AddressDao {
	
	private static Logger LOGGER = Logger.getLogger(AccountDaoImpl.class);
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Long saveAddress(Address address) throws IBSCustomException {
		LOGGER.info("Into saveAddress method");
		Long result = new Long(0);
		if (address != null) {
			LOGGER.debug("Address exists to add");
			entityManager.persist(address);
			LOGGER.info("Address is saved.");
		} else {
			throw new IBSCustomException(IBSException.invalidApplicantId);
		}
		return result;
	}

	@Override
	public Address getAddress(long applicantId) throws IBSCustomException {
		LOGGER.info("Into getAddress method");
		Address address = new Address();
		if (applicantId != 0) {
			LOGGER.debug("Finding applicant Id");
			address = entityManager.find(Address.class, applicantId);
		} else {
			LOGGER.error("Address doesn't exist.");
			throw new IBSCustomException(IBSException.applicantNotFound);
		}
		return address;
	}

}
