package com.cg.ibs.im.model;

public enum ApplicationStatus {
	PENDING, APPROVED, DENIED;
}
