package com.cg.ibs.im.dao;

import java.util.Set;

import com.cg.ibs.im.exception.IBSCustomException;
import com.cg.ibs.im.model.ApplicationStatus;
import com.cg.ibs.im.model.Application;

public interface ApplicationDao {

	Long saveApplication(Application application) throws IBSCustomException;

	Set<Long> getAllApplications() throws IBSCustomException;

	Application getApplicationDetails(Long applicationId) throws IBSCustomException;

	Set<Application> getApplicationByStatus(ApplicationStatus applicationStatus) throws IBSCustomException;

	boolean isApplicationPresent(Long applicationId) throws IBSCustomException;

	boolean updateApplication(Application application) throws IBSCustomException;


}