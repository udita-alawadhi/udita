package com.cg.ibs.im;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbsV8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
